const inputBox = document.querySelector('.input-box');
const searchBtn = document.getElementById('searchBtn');
const weather_img = document.querySelector('.Weather-img');
const temp = document.querySelector('.temp');
const description = document.querySelector('.description');
const humidity = document.getElementById('humidity');
const wind_speed = document.getElementById('wind-speed');
const location_not_found = document.querySelector('.location-not-found');
const weather_body = document.querySelector('.weather-body');


document.querySelector('.check').addEventListener('click', () => {
    document.querySelector('.search_box').style.display = 'block';
    document.querySelector('.weather-body').style.display = 'block';
    document.querySelector('.check').style.display = 'none';
});


async function checkWeather(city) {
    const API_key = "944c7be708af36ceb6624ad373a3c87d"
    const URL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_key}`;
    const weather_data = await fetch(`${URL}&q=${city}`).then(Response => Response.json());
    /// not found////

    if (weather_data.cod === '404') {
        location_not_found.style.display = "flex";
        weather_body.style.display = "none";
        return;
    } else {
        location_not_found.style.display = "none";
        weather_body.style.display = "block";
    }

    temp.innerHTML = `${Math.round(weather_data.main.temp - 273.15)}°C `;
    description.innerHTML = `${weather_data.weather[0].description}`;
    humidity.innerHTML = `${weather_data.main.humidity}%`;
    wind_speed.innerHTML = `${weather_data.wind.speed}Km/H`;

    switch (weather_data.weather[0].main) {
        case 'Clouds':
            weather_img.src = "img/cloud.png";
            break;
        case 'Clear':
            weather_img.src = "img/clear.png";
            break;
        case 'Mist':
            weather_img.src = "img/mist.png";
            break;
        case 'Rain':
            weather_img.src = "img/rain.png";
            break;
        case 'Snow':
            weather_img.src = "img/snow.png";
            break;
    }
}

searchBtn.addEventListener('click', () => {
    document.querySelector('.weather-box').style.display = 'block';
    document.querySelector('.weather-details').style.display = 'block';
    const city = inputBox.value.trim();
    if (city === '') {
        location_not_found.innerHTML = 'Please type your location';
        location_not_found.style.display = "flex";
        weather_body.style.display = "none";
    } else {
        checkWeather(city);

    }
});


